-- ResQBite database setup (Supabase > SQL Editor > New query > paste > Run)
-- Safe to run more than once.

create table if not exists rb_users (id bigint primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists rb_lists (id bigint primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists rb_reqs  (id bigint primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists rb_notes (id bigint primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists rb_inc   (id bigint primary key, data jsonb not null, updated_at timestamptz not null default now());

-- keep updated_at fresh on every write
create or replace function rb_touch() returns trigger as $$
begin new.updated_at = now(); return new; end; $$ language plpgsql;

do $$
declare t text;
begin
  foreach t in array array['rb_users','rb_lists','rb_reqs','rb_notes','rb_inc'] loop
    execute format('drop trigger if exists %I_touch on %I', t, t);
    execute format('create trigger %I_touch before insert or update on %I for each row execute function rb_touch()', t, t);
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists %I_rw on %I', t, t);
    execute format('create policy %I_rw on %I for all to anon, authenticated using (true) with check (true)', t, t);
    execute format('grant select, insert, update on %I to anon, authenticated', t);
  end loop;
end $$;
